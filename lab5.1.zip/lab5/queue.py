# Alexander Halac
# CSC-231-002

class Queue:
    """
    DO NOT change the name of the class. All class methods must have self as the first parameter.

    Implement the following methods:
    __init__(): the class constructor
    enqueue(item): adds item to the rear of the queue
    dequeue(): removes and returns the item at the front of the queue. Returns None if the queue is empty.
    is_empty(): returns True if the queue is empty, False otherwise
    __len__(): supports calls to len(queue_object). returns the number of items in the queue
    """

    def __init__(self): # class constructor

        self.queue = [] # creates a list for FIFO order

    def enqueue(self, item):

        self.queue.append(item) # adds an item to the back of the list

    def dequeue(self):

        if len(self.queue) != 0: # makes sure the list is not empty
            front = self.queue[0] # saves front item
            del self.queue[0] # removes front item
            return front # returns front item
        else:
            return None # returns None if list is empty

    def is_empty(self):

        if len(self.queue) == 0: # returns True if list is empty, False otherwise
            return True
        else:
            return False

    def __len__(self):

        return len(self.queue) # returns the number of items in the list

if __name__ == '__main__':
    # You may add code below this line to help you test.

    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.

    from tests import QueueTests
    import sys

    suite = QueueTests(sys.modules[__name__])
    suite.test_01_constructor()
    suite.test_02_enqueue_dequeue()
    suite.test_03_dequeue_empty()
    suite.test_04_is_empty()
    suite.test_05__len__()