# Alexander Halac
# CSC-231-002

from stack import Stack

def KeyStrokeReader(file): # creating a function to read all three different messages

    fileOpen = open(file, "r") # initializes variables
    Message = Stack() # creates a stack
    Text1 = fileOpen.read() # opens the file

    for x in range(len(Text1)):

        Message.push(Text1[x]) # adds every item to the stack

        if Text1[x] == "<": # detects backspaces
            Message.pop() # removes the backspace and the item entered before it
            Message.pop()
        
    print(Message) # prints the message

KeyStrokeReader("undo/undo1.txt") # calling the function to read all three files
KeyStrokeReader("undo/undo2.txt")
KeyStrokeReader("undo/undo3.txt")