# Alexander Halac
# CSC-231-002

class Stack:
    """
    DO NOT change the name of the class. All class methods must have self as the first parameter.

    Implement the following methods:
    __init__(): the class constructor
    push(item): adds item to the top of the stack
    pop(): removes and returns the top item on the stack. Returns None if the stack is empty.
    peek(): returns the top item on the stack, but does not remove it. Returns None if the stack is empty.
    is_empty(): returns True if the stack is empty, False otherwise
    __len__(): supports calls to len(stack_object). returns the number of items in the stack
    """

    def __init__(self): # Class constructor

        self.stack = [] # Creates a list for LIFO order

    def push(self, item): # appends an item to the top of a stack, or in this case the top of a list

        self.stack.append(item)

    def pop(self): # returns and removes the last item in a list
        
        if len(self.stack) != 0: # checks if the list is empty
            Last = len(self.stack) - 1 # gets the index of the top item in the list
            stackLast = self.stack[Last] # saves the top item before removing
            del self.stack[Last] # deletes top item in the list
            return stackLast # returns what was saved
        else: # returns None if the list is empty
            return None
    

    def peek(self): # returns the top item in the list
        if len(self.stack) != 0: # does the same thing as pop but without deleting the top item
            Last = len(self.stack) - 1
            return self.stack[Last]
        else:
            return None

    def is_empty(self): # checks if the list is empty of not

        if len(self.stack) == 0: # returns true if nothing is found
            return True
        else:
            return False # false otherwise

    def __len__(self): # returns the number of items in the list

        return len(self.stack)

    def __str__(self): # formats stack in a readable form

        stack = "" # initializes variable

        for x in range(len(self.stack)): # will concattenate every item in the list to stack one by one

            stack = str(stack) + str(self.stack[x])

        return stack


if __name__ == '__main__':
    # You may add code below this line to help you test.


    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.

    from tests import StackTests
    import sys
    suite = StackTests(sys.modules[__name__])
    suite.test_01_constructor()
    suite.test_02_push_pop()
    suite.test_03_pop_empty()
    suite.test_04_peek()
    suite.test_05_peek_empty()
    suite.test_06_is_empty()
    suite.test_07__len__()

