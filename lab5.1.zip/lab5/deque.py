# Alexander Halac
# CSC-231-002

class Deque:
    """
    DO NOT change the name of the class. All class methods must have self as the first parameter.

    Implement the following methods:
    __init__(): the class constructor
    add_front(item): adds item to the front of the deque
    add_rear(item): adds item to the rear of the deque
    remove_front(): removes and returns the item at the front of the deque. Returns None if the deque is empty.
    remove_rear(): removes and returns the item at the rear of the deque. Returns None if the deque is empty.
    is_empty(): returns True if the queue is empty, False otherwise
    __len__(): supports calls to len(dequeue_object). returns the number of items in the deque
    """

    def __init__(self): # class constructor

        self.deque = [] # creates a list to add or remove elements

    def add_front(self, item): # adds an item to the front of the list

        self.deque.insert(0, item) # inserts at index 0

    def add_rear(self,item): # adds an item to the back of the list

        self.deque.append(item) # appends item to back

    def remove_front(self):

        if len(self.deque) != 0: # checks if the list is empty
            front = self.deque[0] # saves front
            del self.deque[0] # then deletes front
            return front # returns what was saved
        else:
            return None # returns None if empty list

    def remove_rear(self):

        if len(self.deque) != 0: # does the same thing as remove_front but for the back of the list instead of front
            rear = self.deque[-1]
            del self.deque[-1]
            return rear
        else:
            return None

    def is_empty(self):

        if len(self.deque) == 0: # returns True if the list is empty
            return True
        else:
            return False # false otherwise

    def __len__(self):

        return len(self.deque) # returns the number of items in the list



if __name__ == '__main__':
    # You may add code below this line to help you test.

    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.

    from tests import DequeTests
    import sys

    suite = DequeTests(sys.modules[__name__])
    suite.test_01_constructor()
    suite.test_02_adds_and_removes()
    suite.test_03_remove_empty()
    suite.test_04_is_empty()
    suite.test_05__len__()