# Alexander Halac
# CSC-231-002
# 9/16/2026

from fraction import Fraction


# DRIVER TEST

# Testing Constructor

frac1 = Fraction(1,2)
frac2 = Fraction(2,3)
frac3 = Fraction(3,5)

print("Testing Constructor")
print("Fraction 1:",frac1)
print("Fraction 2:",frac2)
print("Fraction 3:",frac3)
print()

print("Testing GetNumerator and GetDenominator")
print("Fraction 1:",frac1.getNumerator())
print("Fraction 2:",frac2.getNumerator())
print("Fraction 3:",frac3.getNumerator())
print()
print("Fraction 1:",frac1.getDenominator())
print("Fraction 2:",frac2.getDenominator())
print("Fraction 3:",frac3.getDenominator())
print()

print("Testing SetNumerator and SetDenominator")
print("Doubling all the Fractions")
frac1.setNumerator(2)
frac1.setDenominator(4)
frac2.setNumerator(4)
frac2.setDenominator(6)
frac3.setNumerator(6)
frac3.setDenominator(10)

print("Fraction 1:",frac1)
print("Fraction 2:",frac2)
print("Fraction 3:",frac3)
print()

print("Testing Reduce by Greatest Common Denominator")
frac1.reduce()
frac2.reduce()
frac3.reduce()

print("Fraction 1:",frac1)
print("Fraction 2:",frac2)
print("Fraction 3:",frac3)
print()

print("Testing Negate")

print("Fraction 1:",-frac1)
print("Fraction 2:",-frac2)
print("Fraction 3:",-frac3)
print()

print("Testing Addition")
print("Fraction 1 + Fraction 2:",frac1+frac2)
print("Fraction 1 + Fraction 3:",frac1+frac3)
print("Fraction 3 + Fraction 2:",frac3+frac2)
print()

print("Testing Subtraction")
print("Fraction 1 - Fraction 2:",frac1-frac2)
print("Fraction 1 - Fraction 3:",frac1-frac3)
print("Fraction 3 - Fraction 2:",frac3-frac2)
print()

print("Testing Multiplication")
print("Fraction 1 * Fraction 2:",frac1*frac2)
print("Fraction 1 * Fraction 3:",frac1*frac3)
print("Fraction 3 * Fraction 2:",frac3*frac2)
print()

print("Testing Division")
print("Fraction 1 / Fraction 2:",frac1/frac2)
print("Fraction 1 / Fraction 3:",frac1/frac3)
print("Fraction 3 / Fraction 2:",frac3/frac2)
print()

print("Testing Equal To")
print("Fraction 1 == Fraction 2:",frac1==frac2)
print("Fraction 1 == Fraction 3:",frac1==frac3)
print("Fraction 3 == Fraction 2:",frac3==frac2)
print()

print("Testing Not Equal To")
print("Fraction 1 != Fraction 2:",frac1!=frac2)
print("Fraction 1 != Fraction 3:",frac1!=frac3)
print("Fraction 3 != Fraction 2:",frac3!=frac2)
print()

print("Testing Less Than")
print("Fraction 1 < Fraction 2:",frac1<frac2)
print("Fraction 1 < Fraction 3:",frac1<frac3)
print("Fraction 3 < Fraction 2:",frac3<frac2)
print()

print("Testing Less Than or Equal To")
print("Fraction 1 <= Fraction 2:",frac1<=frac2)
print("Fraction 1 <= Fraction 3:",frac1<=frac3)
print("Fraction 3 <= Fraction 2:",frac3<=frac2)
print()

print("Testing Greater Than")
print("Fraction 1 > Fraction 2:",frac1>frac2)
print("Fraction 1 > Fraction 3:",frac1>frac3)
print("Fraction 3 > Fraction 2:",frac3>frac2)
print()

print("Testing Greater Than or Equal To")
print("Fraction 1 >= Fraction 2:",frac1>=frac2)
print("Fraction 1 >= Fraction 3:",frac1>=frac3)
print("Fraction 3 >= Fraction 2:",frac3>=frac2)
print()