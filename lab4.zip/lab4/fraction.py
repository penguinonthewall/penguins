# Alexander Halac
# CSC-231-002
# 9/16/2026

class Fraction(): # creating fraction class

    def __init__(self, numerator = 0, denominator = 0):

        self.numerator = numerator # sets numerator and denominator
        self.denominator = denominator

        if self.denominator == 0: # if denominator is zero then a ValueError is raised
            raise ValueError
        elif self.denominator < 0: # a value error is raised as well if the denominator is negative
            raise ValueError

    def __str__(self):
        return f"{self.numerator}/{self.denominator}" # print format

    def getNumerator(self): # returns the numerator
        return self.numerator

    def getDenominator(self): # returns denominator
        return self.denominator

    def setNumerator(self, numerator = 0): # sets the numerator to a new number
        self.numerator = numerator

    def setDenominator(self, denominator = 0):
        self.denominator = denominator # sets the denominator to a new number

    def reduce(self): # reduces the fraction by the greatest common divisor
        GCD = self.__calcGCD()

        self.numerator = self.numerator // GCD # divides the numerator and denominator by the greatest common divisor between the two
        self.denominator = self.denominator // GCD

        return self

    def __calcGCD(self): # finds the greatest common denominator
        m = self.numerator
        n = self.denominator

        while m % n != 0:
            oldm = m
            oldn = n

            m = oldn
            n = oldm % oldn
        return n

    def __neg__(self): # sets the fraction negative
        return (-self.numerator,self.denominator)

    def __add__(self, self2): # adds two fractions together
        numerator = self.numerator * self2.denominator + self2.numerator * self.denominator
        denominator = self.denominator * self2.denominator
        
        return Fraction(numerator, denominator).reduce()

    def __sub__(self, self2): # subtracts two fractions
        numerator = self.numerator * self2.denominator - self2.numerator * self.denominator
        denominator = self.denominator * self2.denominator

        Fraction(numerator,denominator).reduce()
        
        return Fraction(numerator, denominator).reduce()

    def __mul__(self, self2): # multiplies two fractions
        numerator = self.numerator * self2.numerator
        denominator = self.denominator * self2.denominator

        return Fraction(numerator, denominator).reduce()

    def __truediv__(self, self2): # divides two fractions
        numerator = self.numerator * self2.denominator
        denominator = self.denominator * self2.numerator

        return Fraction(numerator, denominator).reduce()

    def __eq__(self, self2): # checks if two fractions are equal to each other
        if (self.numerator / self.denominator == self2.numerator / self2.denominator):
            return True
        else:
            return False

    def __ne__(self, self2): # checks if two fractions are not equal to each other
        if (self.numerator / self.denominator != self2.numerator / self2.denominator):
            return True
        else:
            return False

    def __lt__(self, self2): # checks if a fraction is less than another fraction
        if (self.numerator / self.denominator < self2.numerator / self2.denominator):
            return True
        else:
            return False

    def __le__(self, self2): # checks if a fraction is less than or equal to another fraction
        if (self.numerator / self.denominator <= self2.numerator / self2.denominator):
            return True
        else:
            return False

    def __gt__(self, self2): # checks if a fraction is greater than another fraction
        if (self.numerator / self.denominator > self2.numerator / self2.denominator):
            return True
        else:
            return False

    def __ge__(self, self2): # checks if a fraction is greater than or equal to another fraction
        if (self.numerator / self.denominator >= self2.numerator / self2.denominator):
            return True
        else:
            return False


if __name__ == "__main__":
    
    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.

    from tests import FractionTests
    import sys
    suite = FractionTests(sys.modules[__name__])
    suite.test_01_constructor_basic()
    suite.test_02_constructor_negative_numerator()
    suite.test_03_constructor_denom_zero_error()
    suite.test_04_constructor_denom_negative_error()
    suite.test_05_reduce_basic()
    suite.test_06_reduce_negative()
    suite.test_07_addition_simple()
    suite.test_08_subtraction()
    suite.test_09_multiplication()
    suite.test_10_division()
    suite.test_11_equality_true_unreduced()
    suite.test_12_equality_false()
    suite.test_13_greater_than()
    suite.test_14_less_than()
    suite.test_15_comparison_equal()