# Alexander Halac
# CSC-231, Section 002
# 9/8/2026

class FootMeasure:

    def __init__(self, feet = 0, inches = 0): # class constructor

        self.feet = (feet + inches//12) # calculates the number of feet
        self.inches = (((feet*12) + inches) % 12) # calculate the number of inches

        self.totalInch = feet*12 + inches # total number of inches for relational operators

    def __str__(self): # for print format

        return f"{self.feet} ft. {self.inches} ins." 

    def __add__(self, self2): # adds two different measures of inches by calculating the total number of inches and adding them together

        totalInch = (self.feet * 12) + self.inches 
        totalInch2 = (self2.feet * 12) + self2.inches

        return FootMeasure(inches = totalInch + totalInch2)

    def __eq__(self, self2): # checks if they are equal

        return self.totalInch == self2.totalInch

    def __ne__(self, self2): # checks if they are not equal to each other

        return self.totalInch != self2.totalInch

    def __gt__(self, self2): # checks if the first one is greater than

        return self.totalInch > self2.totalInch

    def __ge__(self, self2): # checks if the first one is greater than or equal to

        return self.totalInch >= self2.totalInch

    def __lt__(self, self2): # checks if the first one is less than

        return self.totalInch < self2.totalInch

    def __le__(self,self2): # checks if the first one is less than or equal to

        return self.totalInch <= self2.totalInch

if __name__ == "__main__":
    # You may add code below this line to help you test.


    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.

    from tests import FootMeasureTests
    import sys
    suite = FootMeasureTests(sys.modules[__name__])
    suite.test_01_zero_measure()
    suite.test_02_simple_measure()
    suite.test_03_inches_only()
    suite.test_04_normalization()
    suite.test_05_addition_simple()
    suite.test_06_addition_with_carry()
    suite.test_07_equality_true()
    suite.test_08_equality_false()
    suite.test_09_greater_than()
    suite.test_10_less_than()
    suite.test_11_greater_equal_and_less_equal()