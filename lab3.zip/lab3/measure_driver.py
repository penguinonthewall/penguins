from measure import FootMeasure

# Alexander Halac
# CSC-231-002
# 9/8/2026

# DRIVER TESTS

# Creating Different Measures

fm1 = FootMeasure(feet = 0, inches = 25)
fm2 = FootMeasure(feet = 4, inches = 0)
fm3 = FootMeasure(feet = 3, inches = 10)

# Printing the Different Measures to Check Formatting

print("Testing Formatting and Constructor")
print("Expected: 2 ft. 1 ins.")
print(fm1)

print("Expected: 4 ft. 0 ins.")
print(fm2)

print("Expected: 3 ft. 10 ins.")
print(fm3)
print()

# Testing Addition

print("Testing Addition")

print("Expected: 7 ft. 10 ins.")
print(fm2 + fm3)

print("Expected: 5 ft. 11 ins.")
print(fm1 + fm3)

print("Expected: 6 ft. 1 ins.")
print(fm1 + fm2)
print()

# Testing the Relational Operators

print("Testing Relational Operators")

print("Testing Equal To")
print("Expected: False")
print(fm1 == fm2)
print()

print("Testing Not Equal To")
print("Expected: True")
print(fm1 != fm2)
print()

print("Testing Greater Than")
print("Expected: False")
print(fm1 > fm2)
print()

print("Testing Greater Than Equal To")
print("Expected: False")
print(fm1 >= fm3)
print()

print("Testing Less Than")
print("Expected: True")
print(fm1 < fm2)
print()

print("Testing Less Than Equal To")
print("Expected: True")
print(fm1 <= fm2)
print()