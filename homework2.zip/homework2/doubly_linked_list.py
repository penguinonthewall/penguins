# Alexander Halac
# CSC-231-002
# 10/7/2026

class Node:

    def __init__(self, data, previous = None, next = None): # class constructor
        
        self.data = data
        self.prev = previous
        self.next = next

    def __str__(self):

        return f"Node(data={self.data})"

class DoublyLinkedList:

    def __init__(self): # class constructor
        
            self.head = None # initializes variables and parts of the linked list
            self.tail = None
            self.size = 0 # keeps track of list size

    def is_empty(self): # returns True if list is empty, False otherwise

        if self.size <= 0:
            return True
        else:
            return False

    def add(self, item):

        new_node = Node(item, next = self.head) # creates a new node for the new "head" of the list

        if self.head != None : # sets the previous node if the list is not empty
            next_node = new_node.next
            next_node.prev = new_node
        
        self.head = new_node # sets the new node as the head
        new_node.prev = None

        if self.size <= 0: # if the list is empty, sets the new head as the tail as well
            self.tail = new_node
            new_node.next = None
                
        self.size += 1 # keeps track of list size

        

    def __iter__(self): # for iterating over items in list 

        current = self.head
        while current is not None:
            yield current
            current = current.next

    def append(self, item):

        new_node = Node(item)

        if self.size == 0: # incase the list is empty, sets the new tail as the head as well
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node # creates the new tail
            new_node.prev = self.tail
            self.tail = new_node # sets the pointer to previous node

        self.size += 1 # keeps track of size

    def pop(self, pos = None):

        if pos == str: # if position was entered as a string and not an integer
            raise TypeError

        if pos == int: # only runs check if pos is an integer so there are no "none type" comparisons
            if pos > self.size: # incase the position entered is outside of the list's range
                raise IndexError

        if self.size == 0: # make sure the list isnt empty when being popped
            raise IndexError("List is empty")

        if pos != int: # if pos is equal to None
            if pos == None: # pops the end of the list if nothing is entered
                if self.size == 1: # incase there is only one element in the list
                    current_node = self.head
                    self.head = None
                    self.tail = None
                    self.size -= 1
                    return current_node
                
                current_node = self.tail # deletes the node
                self.tail = self.tail.prev
                self.tail.next = None

                self.size -= 1 # update list size
                return current_node.data # returns the tail data

        if pos == 0: # incase the head is being popped

            if self.size == 1: # incase there is only one element in the list
                current_node = self.head
                self.head = None
                self.tail = None
                self.size -= 1
                return current_node

    
            current_node = self.head
            self.head = self.head.next
            self.head.prev = None
            self.size -= 1

            return current_node.data


        else: # for popping anything that isnt the head or tail of the list

            current_node = self.head # initialize node for traveling to the position

            for x in range(pos - 1): # travels to the entered position of the node
                current_node = current_node.next

                if current_node.next == None: # just in case to prevent everything from breaking
                    raise IndexError

            if current_node == self.tail: # incase tail is being popped
                current_node = self.tail
                
                self.tail = self.tail.prev
                self.tail.next = None

                self.size -= 1
                return current_node.data

            return_node = current_node.next # pops any middle nodes
            current_node.next = return_node.next # re-initialize next and previous pointers in the nodes
            return_node.prev = current_node

            self.size -= 1

            return return_node.data



    def search(self, item): # determines if an item is in the list or not
        
        current_node = self.head

        while current_node != None:
            if current_node.data == item:
                return True # return True if the item is found
            else:
                current_node = current_node.next
        
        return False # false otherwise

    def remove(self, item):

        current_node = self.head # initializes variables
        previous_node = None

        while current_node != None:    

            if self.size == 1 and self.head.data == item: # incase the item is the only item in the list
                self.head = None
                self.tail = None
                self.size -= 1
                return

            elif self.size == 0: # incase the list is empty
                raise ValueError
            
            elif current_node.data == item:
                if previous_node == None: # incase the head is being removed
                    self.head = current_node.next
                    self.head.prev = None
                elif current_node == self.tail: # incase the tail is the one being deleted
                    self.tail = previous_node
                    self.tail.next = None
                else:
                    previous_node.next = current_node.next # deletes the specified node if found
                    current_node.next.prev = previous_node # update previous node
                self.size -= 1
                return

            previous_node = current_node # sets up the next nodes to be checked
            current_node = current_node.next

        raise ValueError # if the item doesnt exist        


if __name__ == '__main__': 
    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.
    from tests_ll import DLLTests
    import sys
    suite = DLLTests(sys.modules[__name__])
    suite.test_01_node_basic()
    suite.test_02_dll_init_is_empty()
    suite.test_03_add_basic_and_links()
    suite.test_04_append_basic_and_links()
    suite.test_05_append_to_empty()
    suite.test_06_iter_basic()
    suite.test_07_search()
    suite.test_08_remove_head_tail_middle_links()
    suite.test_09_remove_only_element_and_missing()
    suite.test_10_pop_tail_head_middle()
    suite.test_11_pop_errors_and_types()