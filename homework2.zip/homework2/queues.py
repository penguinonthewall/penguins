# Alexander Halac
# CSC-231-002

from doubly_linked_list import DoublyLinkedList

class QueuePythonList: # queue implemented with python list

    def __init__(self): # class constructor

        self.queue = [] # creates a list for FIFO order

    def enqueue(self, item):

        self.queue.append(item) # adds an item to the back of the list

    def dequeue(self):

        if len(self.queue) != 0: # makes sure the list is not empty
            front = self.queue[0] # saves front item
            del self.queue[0] # removes front item
            return front # returns front item
        else:
            return None # returns None if list is empty

    def is_empty(self):

        if len(self.queue) == 0: # returns True if list is empty, False otherwise
            return True
        else:
            return False

    def __len__(self):

        return len(self.queue) # returns the number of items in the list    

class QueueLinkedList: # queue implemented with linked list

    def __init__(self): # class constructor

        self.queue = DoublyLinkedList()

    def enqueue(self, item):

        self.queue.append(item) # adds an item to the back of the list

    def dequeue(self):

        if self.queue.head == None:
            return None
        if self.queue.size != 0: # makes sure the list is not empty
            front = self.queue.head # saves front item
            self.queue.pop(0) # removes front item
            return front.data # returns front item
        else:
            return None # returns None if list is empty

    def is_empty(self):

        if self.queue.head == None:
            return True
        elif self.queue.size == 0: # returns True if list is empty, False otherwise
            return True
        else:
            return False

    def __len__(self):

        return self.queue.size # returns the number of items in the list    


if __name__ == '__main__':
    # You may add code below this line to help you test.

    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.

    from tests_queue import QueueTests
    import sys

    print("===== Testing QueuePythonList =====")
    suite = QueueTests(sys.modules[__name__], "QueuePythonList")
    suite.test_01_constructor()
    suite.test_02_enqueue_dequeue()
    suite.test_03_dequeue_empty()
    suite.test_04_is_empty()
    suite.test_05__len__()

    print("\n===== Testing QueueLinkedList =====")
    suite = QueueTests(sys.modules[__name__], "QueueLinkedList")
    suite.test_01_constructor()
    suite.test_02_enqueue_dequeue()
    suite.test_03_dequeue_empty()
    suite.test_04_is_empty()
    suite.test_05__len__()
