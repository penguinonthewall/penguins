# Alexander Halac
# CSC-231-002
# 10/2/2026



class Node(): # node class to point to the next piece of data

    def __init__(self, data, next=None): # class constructor

        self.data = data # keeps track of the data
        self.next = next # points to the next "node"

    def __str__(self):

        return f"Node(data={self.data})"

class LinkedList():

    def __init__(self): # class constructor

        self.head = None # initializes variables and parts of the linked list
        self.tail = None
        self.size = 0 # keeps track of list size

    def is_empty(self): # returns True if list is empty, False otherwise

        if self.size <= 0:
            return True
        else:
            return False

    def add(self, item): # adds an item to the front of list making it the new "head"

        new_node = Node(item, self.head) # creates a new node for the new "head" of the list

        self.head = new_node # sets the new node as the head

        if self.size <= 0: # if the list is empty, sets the new head as the tail as well
            self.tail = new_node
        
        self.size += 1 # keeps track of list size


    def __iter__(self): # for iterating over items in list 

        current = self.head
        while current is not None:
            yield current
            current = current.next

    def append(self, item): # adds an item to the end of the list creating a new "tail"

        new_node = Node(item)

        if self.size == 0: # incase the list is empty, sets the new tail as the head as well
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node # creates the new tail
            self.tail = new_node

        self.size += 1 # keeps track of size

    def pop(self, pos = None): # removes and returns an item at a position in the list

            current_node = self.head # initializing variables
            previous_node = None

            if self.size == 0: # incase the list is empty
                raise IndexError

            if pos != None:
                if pos > self.size: # incase the position is greater than the amount of items in the list
                    raise IndexError
            
            if pos != None: # goes through the list to reach the specified position
                for x in range(pos):
                    previous_node = current_node
                    current_node = current_node.next
            else: # run again if no position is specified to keep track of the node before the tail
                for x in range(self.size - 1):
                    previous_node = current_node
                    current_node = current_node.next

            if pos == None: # pops the tail if no position is specified
                tail = self.tail
                self.tail = None
                self.tail = previous_node
                self.size -= 1
                return tail.data
        
            if current_node == self.tail: # pops the tail again if the tail is being popped with its position specified
                tail = self.tail
                self.tail = None
                self.tail = previous_node
                self.size -= 1
                return tail.data
            
            if previous_node == None: # incase the head is being popped
                head = self.head
                self.head = current_node.next
                self.size -= 1
                return head.data

            popdata = current_node # for popping anything that isnt the head or tail in the list
            previous_node.next = current_node.next
            self.size -= 1
            return popdata.data

    def search(self, item): # determines if an item is in the list or not
        
        current_node = self.head

        while current_node != None:
            if current_node.data == item:
                return True # return True if the item is found
            else:
                current_node = current_node.next
        
        return False # false otherwise

    def remove(self,item): # removes an item at a position

        current_node = self.head # initializes variables
        previous_node = None

        while current_node != None:

            if current_node == self.tail: # incase the tail is the one being deleted
                self.tail = previous_node
            
            if current_node.data == item:
                if previous_node == None: # incase the head is being removed
                    self.head = current_node.next
                else:
                    previous_node.next = current_node.next # deletes the specified node if found
                self.size -= 1
                return
            
            previous_node = current_node # sets up the next nodes to be checked
            current_node = current_node.next

        raise ValueError # if the item doesnt exist
                



if __name__ == '__main__': 
    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.
    from tests_ll import LLTests
    import sys
    suite = LLTests(sys.modules[__name__])
    suite.test_01_node_basic()
    suite.test_02_ll_init_is_empty()
    suite.test_03_add_basic()
    suite.test_04_append_basic()
    suite.test_05_append_to_empty()
    suite.test_06_iter_basic()
    suite.test_07_search()
    suite.test_08_remove_head_tail_middle()
    suite.test_09_remove_only_element_and_missing()
    suite.test_10_pop_default_and_indices()
    suite.test_11_pop_errors_and_types()