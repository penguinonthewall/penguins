# Alexander Halac
# CSC-231-002


def sequential_search(some_list, some_target):

    for x in range(len(some_list)): # loops until target is found checking one by one

        if some_list[x] == some_target: #target was found
            return (True, x)

    return (False, None) # target was not found


def smart_sequential_search(some_list, some_target):

    index = 0 # initializes variables
    indexTest = 0

    for x in range(len(some_list)): # checks the list for anything that isn't numeric
        if not isinstance(some_list[indexTest], (int, float)):
            raise ValueError
        indexTest += 1

    try:
        while index <= len(some_list): # loops until item is found or if the target is less than the item being checked

            if some_list[index] == some_target: # if target has been found
                return (True, index)
            

            elif some_list[index] > some_target: # if target is smaller than the item being checked
                return (False, None)
            else:
                index += 1 # if item still isnt found
        return (False, None)

    except IndexError: # just a precaution
        return (False, None)


def binary_search(some_list, some_target):

    indexTest = 0 # initializing variable

    for x in range(len(some_list)): # checks the list for anything that isn't numeric
        if not isinstance(some_list[indexTest], (int, float)):
            raise ValueError
        indexTest += 1


    size = len(some_list) # initializing front and back
    ListFront = 0
    ListBack = size - 1

    while ListFront <= ListBack: # loops until target is pinpointed in the list (presuming it exists in the list)

        SearchMiddle = int((ListFront + ListBack) / 2) # re-initializes the middle after every search

        if some_list[SearchMiddle] == some_target: # if the target is found
            return (True, SearchMiddle)

        elif some_list[SearchMiddle] > some_target: # if the target is still greater than the middle
            ListBack = SearchMiddle - 1
        else:
            ListFront = SearchMiddle + 1 # if the target is less than the middle

    return (False, None) # returns false if target does not exist in list




if __name__ == "__main__":

    # Test Lists

    testList1 = [1]
    testList2 = [1,4,6,9,100]
    testList3 = [4,1000000000000000000000,1,14]

    print("Test Lists")
    print("Test List 1:", testList1)
    print("Test List 2:", testList2)
    print("Test List 3:", testList3)
    print()
    
    # Testing Sequential Search

    print("Testing Sequential Search")
    print("List 2")
    print("Checking for 1:",sequential_search(testList2, 1))
    print("Should Return: True, 0")
    print("Checking for 9:",sequential_search(testList2, 9))
    print("Should Return: True, 3")
    print("Testing Does Not Exist:",sequential_search(testList2, 5))
    print("Should Return: False, None")
    print()

    # Testing Smart Sequential Search

    print("Testing Smart Sequential Search")
    print("List 2")
    print("Checking for 1:",smart_sequential_search(testList2, 1))
    print("Should Return: True, 0")
    print("Checking for 9:",smart_sequential_search(testList2, 9))
    print("Should Return: True, 3")
    print("Testing Does Not Exist:",smart_sequential_search(testList2, 5))
    print("Should Return: False, None")
    print()

    # Testing Binary Search

    print("Testing Binary Search")
    print("List 2")
    print("Checking for 1:",binary_search(testList2, 1))
    print("Should Return: True, 0")
    print("Checking for 9:",binary_search(testList2, 9))
    print("Should Return: True, 3")
    print("Testing Does Not Exist:",binary_search(testList2, 5))
    print("Should Return: False, None")
    print() 

    
    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.
    from tests import SearchTests
    import sys
    suite = SearchTests(sys.modules[__name__])
    suite.test_01_sequential_found()
    suite.test_02_sequential_not_found()
    suite.test_03_smart_found()
    suite.test_04_smart_not_found()
    suite.test_05_smart_type_error()
    suite.test_06_binary_found()
    suite.test_07_binary_not_found()
    suite.test_08_binary_type_error()